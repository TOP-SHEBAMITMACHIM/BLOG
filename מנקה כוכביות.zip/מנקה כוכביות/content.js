document.addEventListener('click', function(event) {
    // מציאת הקישור הקרוב ביותר ללחיצה
    let target = event.target.closest('a');
    
    if (target && target.href) {
        // בודק אם הכתובת מכילה כוכבית אחת או יותר
        if (target.href.includes('*')) {
            event.preventDefault(); // עוצר את הפתיחה השגויה
            
            // ניקוי יסודי של כל התווים המיותרים
            let cleanUrl = target.href.replace(/\*/g, '');
            
            // פתיחה בדף חדש
            window.open(cleanUrl, '_blank');
        }
    }
}, true); // הוספת true כדי לתפוס את הלחיצה לפני שהאתר מטפל בה